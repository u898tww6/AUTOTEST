package com.tester.model;

public enum InterfaceName {
    GETUSERLIST,LOGIN,UPDATEUSERINFO,GETUSERINFO,ADDUSERINFO;
}

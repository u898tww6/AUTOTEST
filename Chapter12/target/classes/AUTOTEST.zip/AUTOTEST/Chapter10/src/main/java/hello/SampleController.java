package hello;

public class SampleController {
}
